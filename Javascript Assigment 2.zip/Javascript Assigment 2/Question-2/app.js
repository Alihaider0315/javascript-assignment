// Q.2) Write a program that take 3 numbers from user and print the largest number from these.

const first_num = prompt("Enter Your First Number");
const second_num = prompt("Enter Your Second Number");
const third_num = prompt("Enter Your Third Number");
let largest;

if (first_num >= second_num && first_num >= third_num){

    largest = first_num;

}
else if (second_num >= first_num && second_num >= third_num){
    largest = second_num;
}
else{
        largest = third_num;
}

console.log("The Largest Number Is " , largest);
