// Q.1) Write a program that take student name, five subjects name and their obtained marks out of 
// 100 or 50 as an input from user, and print percentage and grade of the student

let studentName = prompt("Enter Student Name");
let math = prompt("Enter Your First Subject Name");
let mathMarks = +prompt("Enter Your Marks");
let science = prompt("Enter Your Second Subject Name");
let sciMarks = +prompt("Enter Your Marks");
let english = prompt("Enter Your Third Subject Name");
let engMarks = +prompt("Enter Your Marks");
let urdu = prompt("Enter Your Fourth Subject");
let urduMarks = +prompt("Enter Your Marks");
let computer = prompt("Enter Your Fifth Subject Name");
let comMarks = +prompt("Enter Your Marks");

let percentage = mathMarks + sciMarks + engMarks + urduMarks + comMarks;
let per =  percentage / 500 * 100;
console.log(per)


if(per <= 90){
console.log(studentName + " "+ "You got A-one Grade" + " "+ per+"%");

}
else if(per <= 80){
    console.log(studentName + " "+ "You got A Grade" + " "+ per+"%");
}
else if(per <= 70){
    console.log(studentName + " "+ "You got B+ Grade" + " "+ per)+"%";
}
else if(per <= 60){
    console.log(studentName + " "+ "You got c Grade" + " "+ per+"%");
}
else{
    console.log(studentName + "Sorry Grade is not found" + per);

}
