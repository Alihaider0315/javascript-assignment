// Q.4) Take two numbers as starting and ending point of range from user and take another input and 
// check this input is present in a given range or not. If present then print “Number is present ” 
// otherwise print “Number is not present

const range = ('10' , '20' , '30');
let number = prompt("Enter Your Number");
if (range >= number){
    console.log(number,'Your Number Is Present');
}
else {
    console.log(number , 'Your Number Is Not Present Please Try Again');
}
