// Q.3) A triangle has three sides. Take sides as an input from user and check if all sides of triangle are 
// equal then print “Equilateral triangle”, if two sides are equal then print “Isosceles triangle”, If no side 
// is equal then print Scalene triangle” 

const first_num = prompt("Enter Your First Number");
const second_num = prompt("Enter Your Second Number");
const third_num = prompt("Enter Your Third Number");
let triangle;
let Equtri = "Equilateral Triangle";
let Isotri = "Isosceles Triangle";
let Scatri = "Scalene Triangle"

if (first_num == second_num && second_num == third_num){

    triangle = Equtri;

}
else if (first_num == second_num || second_num == third_num || third_num == first_num){

    triangle = Isotri;

}
else{
    triangle = Scatri;

}

console.log("Your Triangel Is Called:" , triangle);
