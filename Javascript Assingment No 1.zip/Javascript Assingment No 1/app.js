// Addition Of Two Numbers

// const a = 10;
// const b = 20;
// const c = a+b;
// console.log('Your Sum Is', c);


// Subscrition Of Two Numbers

// const a = 10;
// const b = 20;
// const c = a-b;
// console.log('Your Subtraction Is', c);

// Multiplication Of Two Numbers

// const a = 10;
// const b = 20;
// const c = a*b;
// console.log('Your Multiplication Is', c);


// Division Of Two Numbers

// const a = 5;
// const b = 20;
// const c = a%b;
// console.log('Your Division Is', c);


// Q.2 Write down the output of the following snippets
// Ans : Output Of This Question Is 10

// const a = 22
// const b = 12
// const c = a%b;
// console.log('Your Answer Is' , c);

// Q.2b. What’s the output of this? If there is any error then resolve this
// Ans : Output Of This Question Is 18
// Wrong Statment 
// const a = 18;
// const c = a++;
// console.log(c);

// Correct Statment
// let a = 18;
// const c = a++;
// console.log(c);

// Q.2c. Write a code which Decrement 2 from 18 by using decrement operator. 
// Ans : Output Of This Question Is 16

// let a = 18;
// let b = --a;
// const c = --b;
// console.log(c);







